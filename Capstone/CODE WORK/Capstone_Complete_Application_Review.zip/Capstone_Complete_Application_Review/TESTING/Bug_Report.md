# Comprehensive Bug & Issue Report

**Project Title:** *Integrated Web Service Interoperability and Data Contract Validation for Reliable System Communication*  
**Date of Audit:** November 19, 2026  
**Auditor Classification:** Pre-Review Quality Assessment

---

## 1. Discovered Bugs and Limitations

### Bug #001: Legacy Sub-URL Route Mismatch in Regression Test Suite
- **Severity:** Low / Test Configuration
- **Status:** Documented / Known
- **Reproduction Steps:**
  1. Run `python test_platform.py`.
  2. Test `test_routes_load` fails with `AssertionError: 404 != 200`.
- **Root Cause:**
  The initial iteration of the application used separate HTML pages served at `/module1`, `/module2`, `/module3`, and `/reports`. When refactored into a modern single-page reactive dashboard with decoupled REST endpoints (`/api/v1/...`), the legacy template routes were deprecated in favor of `/` and JSON endpoints. The older `test_platform.py` still checks for `/module1`, causing a 404.
- **Expected Output:**
  All test routes return HTTP 200.
- **Actual Output:**
  `/module1`, `/module2`, `/module3`, `/reports` return HTTP 404.
- **Recommended Fix:**
  Update `test_platform.py` to assert the modern API paths (`/api/v1/wsdl/parse`, `/api/v1/contract/validate`, `/api/v1/soap/execute`, `/api/v1/reports`), or add simple redirect aliases in `app.py` from `/module1` &rarr; `/#tab-mod1`.

---

### Bug #002: WSDL Recursive Import Limitation
- **Severity:** Medium / Edge Case
- **Status:** Known Limitation
- **Description:**
  `app.py`'s `parse_wsdl_stream()` successfully extracts embedded `<xsd:schema>` inside `<wsdl:types>` and remote addresses. However, if a WSDL uses `<xsd:import schemaLocation="http://external-host/schema.xsd"/>` to import remote schemas over the network, `etree.XMLParser` runs with local entity resolution to prevent SSRF vulnerabilities and will not recursively fetch remote schema files.
- **Reproduction Steps:**
  Upload a WSDL that does not embed its types inline, but instead references an external XSD via `<xsd:import schemaLocation="..." />`.
- **Expected Output:**
  Recursively resolves and compiles external schemas.
- **Actual Output:**
  The schema elements dictionary remains empty; SOAP envelope generator falls back to generic placeholders.
- **Recommended Redesign Fix:**
  Implement a safe schema resolver cache with a timeout and domain allowlist to optionally resolve external `<xsd:import>` schemas.

---

### Bug #003: SOAP 1.2 Action Header Formatting
- **Severity:** Low
- **Status:** Known Limitation
- **Description:**
  For SOAP 1.1, the `SOAPAction` HTTP header is transmitted as `"action_url"`. For SOAP 1.2, WS-Addressing specifies that the action should be placed inside `Content-Type: application/soap+xml; action="action_url"`. While `app.py` correctly handles this in `dispatch_real_soap_request()`, older endpoints that strictly require WS-Addressing SOAP headers in the XML `<soap12:Header>` block may reject requests without `<wsa:Action>` tags.
- **Recommended Fix:**
  Incorporate optional WS-Addressing header injection when SOAP 1.2 is selected.

---

### Bug #004: In-Memory Payload Size & XML Entity Expansion (Billion Laughs)
- **Severity:** Medium / Security
- **Status:** Potential Vulnerability
- **Description:**
  Currently, `lxml.etree.XMLParser` parses user-submitted XML payloads directly. Although `app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024` restricts HTTP body size to 16 MB, malicious nested entity declarations (`<!ENTITY lol "lol">...`) could consume excessive CPU if `resolve_entities=True`.
- **Recommended Fix:**
  Explicitly initialize parsers with `resolve_entities=False` across all XML endpoints.
