-- Database Schema for Web Service Interoperability & Data Contract Validation
-- Engine: SQLite3
-- File: test_history.db

-- Table 1: Configured & Discovered Web Services (Module 1)
CREATE TABLE IF NOT EXISTS configured_services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_name TEXT NOT NULL,
    target_namespace TEXT,
    endpoint_url TEXT NOT NULL,
    wsdl_content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table 2: Contract Validation & Communication Audit Records (Modules 2 & 3)
CREATE TABLE IF NOT EXISTS test_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_name TEXT NOT NULL,
    operation_name TEXT NOT NULL,
    endpoint_url TEXT NOT NULL,
    test_type TEXT NOT NULL,          -- 'CONTRACT_VALIDATION', 'SOAP_COMMUNICATION', 'COMPATIBILITY_CHECK'
    status TEXT NOT NULL,             -- 'PASSED', 'FAILED', 'WARNING'
    response_time_ms REAL,            -- Measured network roundtrip time in milliseconds
    http_status_code INTEGER,         -- 200, 400, 422, 500, etc.
    request_xml TEXT,                 -- Raw XML request envelope transmitted
    response_xml TEXT,                -- Raw XML response or SOAP Fault received
    validation_errors TEXT,           -- JSON array of line/column error diagnostic objects
    compatibility_assessment TEXT,    -- Assessment notes if schema diff executed
    summary TEXT,                     -- Human-readable outcome summary
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_test_records_status ON test_records(status);
CREATE INDEX IF NOT EXISTS idx_test_records_service ON test_records(service_name);
CREATE INDEX IF NOT EXISTS idx_test_records_created ON test_records(created_at);
