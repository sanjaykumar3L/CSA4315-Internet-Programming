# Project Compliance & Objectives Alignment Audit

**Project Title:** *Integrated Web Service Interoperability and Data Contract Validation for Reliable System Communication*  
**Course:** CSA4315 – Internet Programming | Batch: 09  
**Reference Document:** `Documentation/Original_Project_Presentation.pdf`

---

## 1. Compliance Matrix: Presentation Objectives vs Actual Implementation

| Slide # | Stated Presentation Objective | Implemented System Capability | Compliance Status | Audit Remarks |
| :--- | :--- | :--- | :--- | :--- |
| **Slide 4** | *"To develop a web-based platform for configuring and testing web services."* | Developed single-page web platform accessible via browser on `http://127.0.0.1:5000`. | **Fully Compliant** | Operational with tabbed UI and REST API. |
| **Slide 4** | *"To validate XML messages against predefined XML Schema rules."* | Integrated C-level `libxml2` (`lxml.etree.XMLSchema`) performing strict XSD validation. | **Fully Compliant** | Tested and verified against atomic types and complexTypes. |
| **Slide 4** | *"To identify missing fields, incorrect data types and incompatible service contracts."* | Module 2 flags missing elements (`minOccurs >= 1`), type mismatches (`xs:int`, `xs:decimal`), and schema version breaking changes. | **Fully Compliant** | Returns exact line numbers and column offsets. |
| **Slide 4** | *"To test SOAP request-response communication between configured services."* | Module 3 executes real HTTP POST requests with headers and timers; connects to local and remote SOAP endpoints. | **Fully Compliant** | Accurately captures roundtrip latency and catches SOAP Faults. |
| **Slide 4** | *"To generate validation reports that help users identify and correct errors."* | SQLite persistent audit history + automated downloadable PDF reports generated via `ReportLab`. | **Fully Compliant** | Available for all executed tests via `GET /reports/<id>/pdf`. |

---

## 2. Module-by-Module Verification

### **Module 1 — Web Service Configuration and Integration (Slide 9)**
- **WSDL Import:** Supported via file upload and direct XML text paste.
- **Service Discovery:** Discovers service name, target namespace, endpoints, and operations dynamically.
- **Endpoint Configuration:** Captures port addresses, supports SOAP 1.1 / 1.2 selection and SOAPAction headers.
- **XML Request Preparation:** Auto-generates compliant SOAP envelopes with namespace bindings and parameters.
- **Compliance Assessment:** **100% Compliant**.

### **Module 2 — Data Contract Validation and Compatibility Testing (Slide 10)**
- **XML Parsing:** Syntax verification with line-by-line error mapping.
- **Schema Validation:** Strict XSD compilation and validation.
- **Data Type Verification:** Flags atomic type violations (e.g. non-numeric input for `xs:int`).
- **Contract Mismatch Detection:** Distinguishes between missing required tags and unrecognized unexpected tags.
- **Compatibility Assessment:** Compares Schema V1 vs Schema V2 to detect breaking changes (removed fields, increased minOccurs, type changes).
- **Compliance Assessment:** **100% Compliant**.

### **Module 3 — Communication Monitoring and Validation Report Generation (Slide 11)**
- **SOAP Request Execution:** Transmits real HTTP POST to endpoints.
- **Response Verification:** Inspects HTTP status codes and response XML envelopes.
- **Error Tracking & Fault Inspection:** Parses `<faultcode>` and `<faultstring>` from SOAP Fault envelopes.
- **Centralized Test Logging:** Every execution is logged in SQLite (`test_history.db`).
- **Validation Report Generation:** Real-time web table + downloadable PDF reports.
- **Compliance Assessment:** **100% Compliant**.

---

## 3. Analysis of Deviations, Additions & Missing Scope

### Architectural Improvements Made:
1. **Migration from Legacy Java Servlets to Python + `lxml`:**
   - Slide 8 depicted a generic "Java Servlets / JSP" diagram. Replacing this with Python + Flask + `lxml` maintained 100% functional fidelity while avoiding complex external Java application server (Tomcat) prerequisites.
2. **Added Real Mock Services (`/soap/calculator`):**
   - The original presentation did not specify how invigilators would test communication if third-party web services were offline or paywalled. Adding local, self-hosted mock SOAP endpoints solved this completely.
3. **Automated PDF Export:**
   - Added `ReportLab` to produce downloadable official PDF summary certificates for each test execution.

### Missing Scope / Non-Implemented Enhancements:
- **WSDL Recursive `<xsd:import>` Crawling:** The parser does not recursively fetch external schemas referenced over the internet via `schemaLocation` URLs.
- **Authentication Credentials in SOAP Header (WS-Security):** The current client supports standard HTTP headers and unauthenticated SOAP envelopes; WS-Security (`<wsse:Security>`) signature verification is not yet implemented.
