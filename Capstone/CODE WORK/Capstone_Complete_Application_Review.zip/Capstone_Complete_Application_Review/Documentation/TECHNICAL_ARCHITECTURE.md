# Technical Architecture Documentation

**Project Title:** *Integrated Web Service Interoperability and Data Contract Validation for Reliable System Communication*  
**Course Reference:** CSA4315 – Internet Programming  

---

## 1. System Overview & Technology Stack

The platform is designed as an automated, multi-layer validation engine for distributed service contracts. It bridges service discovery, static contract validation, and live dynamic communication testing.

### Technology Stack:
- **Programming Language:** Python 3.13.5 (Backend), JavaScript ES6+ (Frontend)
- **Web Application Framework:** Flask 2.3.3 + Flask-CORS 4.0.0
- **XML & XSD Engine:** `lxml` 6.1.1 (Direct bindings to C-level `libxml2` and `libxslt`)
- **HTTP Transport Client:** `requests` 2.32.5
- **Document Generation:** `reportlab` 4.0.0
- **Persistence Layer:** SQLite 3 (`test_history.db`)
- **Frontend Presentation:** HTML5, CSS3, Bootstrap 5.3.2, Bootstrap Icons 1.11.1

---

## 2. Multi-Layer Architecture Diagram

```mermaid
graph TD
    Client["Client Web Interface (HTML5 / Bootstrap 5 / Vanilla JS Fetch)"]
    
    subgraph Controller_Tier ["Flask Application Controller (app.py)"]
        WsdlAPI["/api/v1/wsdl/parse"]
        EnvAPI["/api/v1/wsdl/generate-envelope"]
        ValAPI["/api/v1/contract/validate"]
        CompatAPI["/api/v1/contract/compatibility"]
        SoapAPI["/api/v1/soap/execute"]
        ReportsAPI["/api/v1/reports"]
        PdfRoute["/reports/:id/pdf"]
    end
    
    subgraph Processing_Tier ["Business & Validation Engines"]
        WsdlParser["Dynamic WSDL Parser (lxml.etree)"]
        XsdEngine["XML Schema 1.0 Engine (lxml.etree.XMLSchema)"]
        DiffEngine["Contract Compatibility Engine"]
        SoapClient["SOAP HTTP Client (requests + time.perf_counter)"]
        PdfBuilder["PDF Report Compiler (ReportLab)"]
    end

    subgraph Service_Tier ["Service & Database Layer"]
        LocalMock["Built-in SOAP Endpoint (/soap/calculator)"]
        ExternalSOAP["Remote SOAP Endpoints (World Wide Web)"]
        SQLiteDB[("SQLite Database (test_history.db)")]
    end

    Client -->|HTTP POST / JSON / FormData| Controller_Tier
    WsdlAPI --> WsdlParser
    EnvAPI --> WsdlParser
    ValAPI --> XsdEngine
    CompatAPI --> DiffEngine
    SoapAPI --> SoapClient
    ReportsAPI --> SQLiteDB
    PdfRoute --> PdfBuilder

    SoapClient -->|Live HTTP POST| LocalMock
    SoapClient -->|Live HTTP POST| ExternalSOAP
    ValAPI -->|Log Test| SQLiteDB
    SoapAPI -->|Log Test & Latency| SQLiteDB
    PdfBuilder -->|Fetch Test Audit| SQLiteDB
```

---

## 3. Data Flow Across Modules

```
[Module 1: Configuration & Integration]
  1. User uploads/pastes WSDL definition.
  2. Backend parses XML, extracts <wsdl:portType>, <wsdl:operation>, <soap:address>.
  3. Client dynamically populates operation dropdown.
  4. Generates compliant SOAP 1.1 / 1.2 request envelope.
                 │
                 ▼
[Module 2: Data Contract Validation & Compatibility]
  1. User feeds XML request instance and XSD contract.
  2. Backend checks syntactic well-formedness (detects line-number XML errors).
  3. C-level libxml2 compiles XSD schema.
  4. Validates element sequence, occurrence constraints (minOccurs/maxOccurs), and data types (xs:int, xs:string, etc.).
  5. Schema Diff Engine evaluates V1 vs V2 contracts to classify breaking vs non-breaking changes.
                 │
                 ▼
[Module 3: Communication Monitoring & Report Generation]
  1. User dispatches SOAP envelope to target endpoint.
  2. High-resolution timer measures network latency (ms).
  3. Real HTTP POST transmitted with Content-Type and SOAPAction headers.
  4. Server response inspected for HTTP status (200, 400, 500) and SOAP Faults (<faultcode>, <faultstring>).
  5. Full audit payload persisted to SQLite database.
  6. Instant downloadable PDF audit report compiled via ReportLab.
```

---

## 4. API Endpoints Specification

### 1. `POST /api/v1/wsdl/parse`
- **Purpose:** Dynamically parses WSDL and extracts operations and endpoints.
- **Input:** JSON `{"wsdl_content": "..."}` or `multipart/form-data` file.
- **Output:** JSON containing `service_name`, `target_namespace`, `endpoints[]`, `operations[]`.

### 2. `POST /api/v1/wsdl/generate-envelope`
- **Purpose:** Constructs an XML SOAP envelope for an operation.
- **Input:** JSON `{"target_namespace": "...", "operation_name": "...", "soap_version": "1.1", "parameters": {...}}`.
- **Output:** JSON `{"status": "success", "request_envelope": "..."}`.

### 3. `POST /api/v1/contract/validate`
- **Purpose:** Strict XSD validation of an XML document.
- **Input:** JSON `{"xml_payload": "...", "xsd_schema": "..."}`.
- **Output:** JSON `{"is_valid": true/false, "status": "PASSED"|"FAILED", "errors": [...], "summary": "..."}`.
- **HTTP Code:** `200 OK` if valid; `422 Unprocessable Entity` if contract violated.

### 4. `POST /api/v1/contract/compatibility`
- **Purpose:** Compares Base Schema (V1) against Updated Schema (V2).
- **Input:** JSON `{"v1_xsd": "...", "v2_xsd": "..."}`.
- **Output:** JSON `{"is_compatible": true/false, "breaking_changes": [...], "non_breaking_changes": [...]}`.

### 5. `POST /api/v1/soap/execute`
- **Purpose:** Dispatches real HTTP POST to SOAP endpoint.
- **Input:** JSON `{"endpoint_url": "...", "request_xml": "...", "soap_action": "...", "soap_version": "1.1"}`.
- **Output:** JSON `{"status": "PASSED"|"FAILED", "http_status_code": int, "latency_ms": float, "is_soap_fault": bool, "response_xml": "..."}`.

### 6. `GET /api/v1/reports`
- **Purpose:** Retrieves recent execution history from SQLite.
- **Output:** JSON `{"status": "success", "records": [...]}`.

### 7. `GET /reports/<int:record_id>/pdf`
- **Purpose:** Streams binary PDF test report (`application/pdf`).

---

## 5. Architectural Deviations from Original PPT Template

| Slide 8 Presentation Architecture | Implemented Production Architecture | Rationale for Deviation |
| :--- | :--- | :--- |
| **Java Servlets & JSP** | Python 3 + Flask + C-level `libxml2` (`lxml`) | Java Servlets / JSP require heavy Tomcat/WAR compilation; Python + `lxml` provides native, industry-standard XML Schema 1.0 compliance and runs zero-setup locally. |
| **Static Form Submissions** | Asynchronous REST API (Vanilla ES6 Fetch) | Prevents page reloads, preserves client-side XML editor state, and provides real-time loading feedback. |
| **Simulated Endpoints** | Built-in Live SOAP Web Service (`/soap/calculator`) | Provides fully functional RFC-compliant SOAP endpoints out of the box without requiring external third-party internet services. |
