# Setup & Execution Instructions

**Project Title:** *Integrated Web Service Interoperability and Data Contract Validation for Reliable System Communication*  
**Course:** CSA4315 – Internet Programming  

---

## 1. System Requirements & Prerequisites

- **Operating System:** Windows 10/11, macOS, or Linux
- **Python Version:** Python 3.10, 3.11, 3.12, or 3.13
- **Web Browser:** Google Chrome, Microsoft Edge, Mozilla Firefox, or Safari (modern version with ES6 Fetch API support)

---

## 2. Installation Steps

### Step 1: Open Terminal in the Backend Folder
```bash
cd Source_Code/Backend
```

### Step 2: Install Python Dependencies
Run pip to install the required production libraries:
```bash
pip install -r requirements.txt
```
*(Dependencies installed: Flask, flask-cors, lxml, requests, reportlab).*

---

## 3. Starting the Application

### Option A: Direct Command
In `Source_Code/Backend/`, execute:
```bash
python app.py
```

### Option B: Windows Batch Launcher
Double-click:
```text
Source_Code/Backend/Start_Project.bat
```

The application server will start and bind to:
```text
* Running on http://127.0.0.1:5000
```

---

## 4. Accessing the User Interface

Open your browser and navigate to:
```text
http://127.0.0.1:5000
```
*(Alternatively, you can open `Source_Code/Frontend/index.html` directly in a browser since CORS is fully enabled on the backend).*

---

## 5. Running Automated Verification Tests

From the `TESTING/` directory, run:

1. **Full-Stack Smoke Test:**
   ```bash
   python TESTING/test_full_stack.py
   ```
   *Expected Output:*
   ```text
   FULL-STACK SMOKE TEST PASSED: All 6 endpoints verified with real data!
   ```

2. **Core Platform Unit Tests:**
   ```bash
   python TESTING/test_platform.py
   ```
   *Note: 4 out of 5 tests pass; test 5 fails due to legacy route refactoring (documented in Bug_Report.md).*

---

## 6. Known Setup Limitations
- **Port 5000 Conflict:** If port 5000 is occupied by another process on your system, change the port in `app.py` (line 520) or launch with `python -m flask run --port 8080`.
- **Offline Operation:** The application includes its own built-in mock SOAP service at `/soap/calculator`, so no external internet access is required to run end-to-end tests.
